import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Bell, Eye, Sliders, Trash2, Key, Save } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { useAuth } from '@/contexts/AuthContext';

export default function Settings() {
  const { user } = useAuth();

  const pageVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5, staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <motion.div variants={pageVariants} initial="hidden" animate="visible" className="p-4 md:p-6 max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-heading font-bold text-text">Account Settings</h1>
        <p className="text-text-secondary mt-1">Manage your account preferences and security.</p>
      </div>

      <motion.div variants={itemVariants}>
        <Card className="glass p-6">
          <h2 className="text-xl font-heading font-semibold text-text mb-6 flex items-center gap-2"><Key className="text-primary" size={20} /> Authentication</h2>
          <div className="space-y-6 max-w-md">
            <div>
              <label className="text-sm font-medium text-text-secondary block mb-2">Email Address</label>
              <Input value={user?.email || 'user@example.com'} disabled className="bg-card-light text-text-muted" />
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-text">Change Password</h3>
              <Input type="password" placeholder="Current Password" />
              <Input type="password" placeholder="New Password" />
              <Input type="password" placeholder="Confirm New Password" />
              <Button className="bg-primary hover:bg-primary/90 text-white shadow-neon-glow"><Save size={16} className="mr-2" /> Update Password</Button>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="glass p-6">
          <h2 className="text-xl font-heading font-semibold text-text mb-6 flex items-center gap-2"><Bell className="text-secondary" size={20} /> Notifications</h2>
          <div className="space-y-4">
            {[
              { title: 'Email Notifications', desc: 'Receive job alerts and updates via email' },
              { title: 'Push Notifications', desc: 'Receive real-time alerts in the browser' },
              { title: 'Marketing Emails', desc: 'Receive tips, newsletters, and promotional offers' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-card-light rounded-lg border border-border-light">
                <div>
                  <h3 className="font-medium text-text">{item.title}</h3>
                  <p className="text-sm text-text-secondary">{item.desc}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked={i !== 2} />
                  <div className="w-11 h-6 bg-card-lighter peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary shadow-[inset_0_2px_4px_rgba(0,0,0,0.4)]"></div>
                </label>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="glass p-6">
          <h2 className="text-xl font-heading font-semibold text-text mb-6 flex items-center gap-2"><Eye className="text-accent" size={20} /> Privacy & Visibility</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-card-light rounded-lg border border-border-light">
              <div>
                <h3 className="font-medium text-text">Profile Visibility</h3>
                <p className="text-sm text-text-secondary">Allow recruiters to find your profile in searches</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-card-lighter peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary shadow-[inset_0_2px_4px_rgba(0,0,0,0.4)]"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-card-light rounded-lg border border-border-light">
              <div>
                <h3 className="font-medium text-text">Show Salary Expectations</h3>
                <p className="text-sm text-text-secondary">Display your target salary on your profile</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-card-lighter peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary shadow-[inset_0_2px_4px_rgba(0,0,0,0.4)]"></div>
              </label>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="glass p-6 border-danger/30">
          <h2 className="text-xl font-heading font-semibold text-danger mb-4 flex items-center gap-2"><Trash2 size={20} /> Danger Zone</h2>
          <p className="text-sm text-text-secondary mb-6">Permanently delete your account and all associated data. This action cannot be undone.</p>
          <Button variant="outline" className="border-danger/50 text-danger hover:bg-danger hover:text-white transition-colors">Delete Account</Button>
        </Card>
      </motion.div>
    </motion.div>
  );
}
