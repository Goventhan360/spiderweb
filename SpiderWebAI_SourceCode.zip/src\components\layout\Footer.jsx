import { Link } from 'react-router-dom';
import { Hexagon, Github, Twitter, Linkedin } from 'lucide-react';
import { APP_NAME, APP_TAGLINE } from '@/utils/constants';

export default function Footer() {
  return (
    <footer className="relative bg-dark-light pt-16 pb-8 border-t border-border overflow-hidden">
      {/* Decorative top border line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent shadow-[0_0_10px_rgba(124,58,237,0.5)]"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Col */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <Hexagon className="w-8 h-8 text-primary" />
              <span className="font-heading font-bold text-xl tracking-wider text-text">
                {APP_NAME}
              </span>
            </Link>
            <p className="text-text-muted text-sm leading-relaxed max-w-xs">
              {APP_TAGLINE}. We use advanced AI to weave the perfect connections between talent and opportunity.
            </p>
            <div className="flex gap-4 pt-2">
              <a href="#" className="w-8 h-8 rounded-full bg-card-light flex items-center justify-center text-text-secondary hover:text-primary hover:bg-primary/10 transition-all">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-card-light flex items-center justify-center text-text-secondary hover:text-primary hover:bg-primary/10 transition-all">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-card-light flex items-center justify-center text-text-secondary hover:text-primary hover:bg-primary/10 transition-all">
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Product */}
          <div>
            <h3 className="font-semibold text-text mb-4">Product</h3>
            <ul className="space-y-3">
              <li><Link to="/features" className="text-sm text-text-muted hover:text-primary transition-colors">Features</Link></li>
              <li><Link to="/ai-tools" className="text-sm text-text-muted hover:text-primary transition-colors">AI Tools</Link></li>
              <li><Link to="/pricing" className="text-sm text-text-muted hover:text-primary transition-colors">Pricing</Link></li>
              <li><Link to="/changelog" className="text-sm text-text-muted hover:text-primary transition-colors">Changelog</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-text mb-4">Company</h3>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-sm text-text-muted hover:text-primary transition-colors">About Us</Link></li>
              <li><Link to="/careers" className="text-sm text-text-muted hover:text-primary transition-colors">Careers</Link></li>
              <li><Link to="/contact" className="text-sm text-text-muted hover:text-primary transition-colors">Contact</Link></li>
              <li><Link to="/privacy" className="text-sm text-text-muted hover:text-primary transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h3 className="font-semibold text-text mb-4">Stay Connected</h3>
            <p className="text-sm text-text-muted mb-4">Join our network for the latest AI career insights.</p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-card-light border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary w-full"
              />
              <button type="submit" className="bg-primary hover:bg-primary/90 text-white rounded-lg px-4 py-2 text-sm font-medium transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-text-muted">
            &copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/terms" className="text-sm text-text-muted hover:text-text transition-colors">Terms</Link>
            <Link to="/privacy" className="text-sm text-text-muted hover:text-text transition-colors">Privacy</Link>
            <Link to="/cookies" className="text-sm text-text-muted hover:text-text transition-colors">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
