import { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase, isSupabaseConfigured } from '@/supabase/client';
import { ROLES } from '@/utils/constants';

const AuthContext = createContext(null);

/* Demo user for when Supabase is not configured */
const DEMO_USERS = {
  candidate: {
    id: 'demo-candidate-001',
    email: 'candidate@demo.spiderweb.ai',
    full_name: 'Alex Morgan',
    role: 'candidate',
    avatar_url: null,
    headline: 'Full Stack Developer | React & Node.js',
    bio: 'Passionate developer with 5 years of experience building scalable web applications.',
    location: 'San Francisco, CA',
    skills: ['React', 'Node.js', 'TypeScript', 'Python', 'PostgreSQL', 'AWS'],
    profile_score: 85,
    resume_score: 78,
    is_available: true,
    phone: '+1 (555) 123-4567',
    github_url: 'https://github.com/alexmorgan',
    linkedin_url: 'https://linkedin.com/in/alexmorgan',
    website: 'https://alexmorgan.dev',
  },
  recruiter: {
    id: 'demo-recruiter-001',
    email: 'recruiter@demo.spiderweb.ai',
    full_name: 'Sarah Chen',
    role: 'recruiter',
    avatar_url: null,
    headline: 'Senior Tech Recruiter at NexaTech Labs',
    bio: 'Helping top talent find their dream roles in tech.',
    location: 'New York, NY',
    skills: [],
    profile_score: 92,
    is_available: true,
  },
  admin: {
    id: 'demo-admin-001',
    email: 'admin@demo.spiderweb.ai',
    full_name: 'Jordan Blake',
    role: 'admin',
    avatar_url: null,
    headline: 'Platform Administrator',
    bio: 'Managing SpiderWeb AI platform operations.',
    location: 'Austin, TX',
    skills: [],
    profile_score: 100,
    is_available: true,
  },
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isDemo, setIsDemo] = useState(false);

  const configured = isSupabaseConfigured();

  /* Fetch user profile from Supabase */
  const fetchProfile = useCallback(async (userId) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setProfile(data);
      return data;
    } catch (err) {
      console.error('Error fetching profile:', err);
      return null;
    }
  }, []);

  /* Initialize auth state */
  useEffect(() => {
    if (!configured) {
      /* Demo mode — check localStorage for demo session */
      const demoRole = localStorage.getItem('spiderweb_demo_role');
      if (demoRole && DEMO_USERS[demoRole]) {
        setUser(DEMO_USERS[demoRole]);
        setProfile(DEMO_USERS[demoRole]);
        setIsDemo(true);
      }
      setLoading(false);
      return;
    }

    /* Real Supabase auth */
    const initAuth = async () => {
      try {
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        setSession(currentSession);
        if (currentSession?.user) {
          setUser(currentSession.user);
          await fetchProfile(currentSession.user.id);
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
      } finally {
        setLoading(false);
      }
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession);
      if (newSession?.user) {
        setUser(newSession.user);
        await fetchProfile(newSession.user.id);
      } else {
        setUser(null);
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [configured, fetchProfile]);

  /* Sign up with email and password */
  const signUp = useCallback(async ({ email, password, full_name, role }) => {
    if (!configured) {
      /* Demo sign up */
      const demoUser = { ...DEMO_USERS[role] || DEMO_USERS.candidate, email, full_name, role };
      setUser(demoUser);
      setProfile(demoUser);
      setIsDemo(true);
      localStorage.setItem('spiderweb_demo_role', role);
      return { user: demoUser, error: null };
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name, role },
      },
    });

    if (!error && data.user) {
      /* Update profile with role */
      await supabase.from('profiles').update({ role, full_name }).eq('id', data.user.id);
    }

    return { user: data?.user, error };
  }, [configured]);

  /* Sign in with email and password */
  const signIn = useCallback(async ({ email, password }) => {
    if (!configured) {
      /* Demo sign in — determine role from email */
      let role = 'candidate';
      if (email.includes('recruiter')) role = 'recruiter';
      if (email.includes('admin')) role = 'admin';
      const demoUser = DEMO_USERS[role];
      setUser(demoUser);
      setProfile(demoUser);
      setIsDemo(true);
      localStorage.setItem('spiderweb_demo_role', role);
      return { user: demoUser, error: null };
    }

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    return { user: data?.user, error };
  }, [configured]);

  /* Sign in with Google */
  const signInWithGoogle = useCallback(async () => {
    if (!configured) {
      const demoUser = DEMO_USERS.candidate;
      setUser(demoUser);
      setProfile(demoUser);
      setIsDemo(true);
      localStorage.setItem('spiderweb_demo_role', 'candidate');
      return { user: demoUser, error: null };
    }

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/candidate/dashboard`,
      },
    });
    return { data, error };
  }, [configured]);

  /* Sign out */
  const signOut = useCallback(async () => {
    if (!configured || isDemo) {
      setUser(null);
      setProfile(null);
      setSession(null);
      setIsDemo(false);
      localStorage.removeItem('spiderweb_demo_role');
      return;
    }

    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);
  }, [configured, isDemo]);

  /* Reset password */
  const resetPassword = useCallback(async (email) => {
    if (!configured) {
      return { error: null };
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    return { error };
  }, [configured]);

  /* Update profile */
  const updateProfile = useCallback(async (updates) => {
    if (!configured || isDemo) {
      const updated = { ...profile, ...updates };
      setProfile(updated);
      setUser((prev) => ({ ...prev, ...updates }));
      return { data: updated, error: null };
    }

    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', user.id)
      .select()
      .single();

    if (!error) setProfile(data);
    return { data, error };
  }, [configured, isDemo, profile, user]);

  const value = useMemo(() => ({
    user,
    profile,
    session,
    loading,
    isDemo,
    isAuthenticated: !!user,
    role: profile?.role || user?.user_metadata?.role || null,
    signUp,
    signIn,
    signInWithGoogle,
    signOut,
    resetPassword,
    updateProfile,
    fetchProfile,
  }), [user, profile, session, loading, isDemo, signUp, signIn, signInWithGoogle, signOut, resetPassword, updateProfile, fetchProfile]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
