import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Hexagon, Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-dark flex items-center justify-center relative overflow-hidden">
      {/* Background elements to match layout */}
      <div className="absolute inset-0 bg-gradient-mesh opacity-30"></div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 text-center px-4 max-w-md"
      >
        <div className="flex justify-center mb-8">
          <div className="relative">
            <Hexagon className="w-16 h-16 mx-auto text-primary animate-bounce-subtle" />
            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full"></div>
          </div>
        </div>
        
        <h1 className="text-7xl font-heading font-black mb-4 gradient-text">404</h1>
        <h2 className="text-2xl font-semibold text-text mb-6">Caught in a broken web</h2>
        <p className="text-text-secondary mb-8">
          The page you are looking for doesn't exist or has been moved to another thread in the network.
        </p>
        
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary hover:bg-primary/90 text-white font-medium transition-all shadow-[0_0_15px_rgba(124,58,237,0.4)]"
        >
          <Home className="w-5 h-5" />
          Return Home
        </Link>
      </motion.div>
    </div>
  );
}
