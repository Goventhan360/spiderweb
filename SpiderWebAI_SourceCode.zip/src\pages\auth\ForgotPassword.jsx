import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link } from 'react-router';
import { Mail, ArrowLeft, Send } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { pageVariants } from '@/hooks/useAnimations';
import toast from 'react-hot-toast';
import { cn } from '@/utils/helpers';

const forgotPasswordSchema = z.object({
  email: z.string().email('Invalid email address'),
});

export default function ForgotPassword() {
  const { resetPassword } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(forgotPasswordSchema),
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    const { error } = await resetPassword(data.email);
    setIsLoading(false);
    
    if (error) {
      toast.error(error.message || 'Failed to send reset email');
    } else {
      setIsSubmitted(true);
    }
  };

  return (
    <motion.div 
      className="min-h-screen flex items-center justify-center p-4 bg-dark relative overflow-hidden"
      variants={pageVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-dark to-dark pointer-events-none" />
      
      <div className="w-full max-w-md glass p-8 rounded-2xl relative z-10 neon-glow">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-heading text-text neon-text mb-2">Reset Password</h1>
          <p className="text-text-secondary">We'll send you instructions to reset your password.</p>
        </div>

        {isSubmitted ? (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto">
              <Mail className="w-8 h-8 text-success" />
            </div>
            <div>
              <h3 className="text-xl font-medium text-text mb-2">Check your email</h3>
              <p className="text-text-secondary">
                We've sent a password reset link to your email address.
              </p>
            </div>
            <Link 
              to="/login"
              className="inline-flex items-center justify-center gap-2 w-full bg-dark-light hover:bg-card border border-border text-text font-medium py-2.5 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Login
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-text-muted" />
                <input 
                  {...register('email')}
                  type="email"
                  placeholder="Email Address"
                  className={cn(
                    "w-full bg-dark-light border rounded-lg py-2.5 pl-10 pr-4 text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors",
                    errors.email ? "border-danger" : "border-border"
                  )}
                />
              </div>
              {errors.email && <p className="text-danger text-sm mt-1">{errors.email.message}</p>}
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              {isLoading ? <span className="animate-spin w-5 h-5 border-2 border-white/30 border-t-white rounded-full" /> : <><Send className="w-5 h-5" /> Send Reset Link</>}
            </button>

            <div className="text-center">
              <Link to="/login" className="inline-flex items-center gap-2 text-text-secondary hover:text-primary transition-colors text-sm">
                <ArrowLeft className="w-4 h-4" />
                Back to Login
              </Link>
            </div>
          </form>
        )}
      </div>
    </motion.div>
  );
}
