import React from 'react';
import { motion } from 'framer-motion';
import { useParams, Link } from 'react-router';
import { MapPin, DollarSign, Briefcase, Clock, Bookmark, Share2, ArrowLeft, Building, Users, Globe, CheckCircle } from 'lucide-react';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';

export default function JobDetail() {
  const { id } = useParams();

  const pageVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <motion.div variants={pageVariants} initial="hidden" animate="visible" className="p-4 md:p-6 max-w-6xl mx-auto space-y-6">
      <Button variant="ghost" size="sm" asChild className="mb-4">
        <Link to="/candidate/jobs" className="flex items-center gap-2 text-text-secondary hover:text-text"><ArrowLeft size={16} /> Back to Search</Link>
      </Button>

      {/* Header Card */}
      <Card className="glass p-6 md:p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex items-start gap-5">
            <div className="w-16 h-16 rounded-xl bg-card-light flex items-center justify-center font-heading font-bold text-3xl text-primary border border-border-light shrink-0">
              C
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-heading font-bold text-text">Senior Frontend Engineer</h1>
              <p className="text-lg text-text-secondary mt-1">CyberDyne Systems</p>
              
              <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-text-secondary mt-4">
                <span className="flex items-center gap-1.5"><MapPin size={16} className="text-primary" /> San Francisco, CA (Hybrid)</span>
                <span className="flex items-center gap-1.5"><DollarSign size={16} className="text-success" /> $140,000 - $180,000</span>
                <span className="flex items-center gap-1.5"><Briefcase size={16} className="text-secondary" /> Full-time</span>
                <span className="flex items-center gap-1.5"><Clock size={16} className="text-accent" /> Posted 2 days ago</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-3 w-full md:w-auto mt-4 md:mt-0">
            <Button className="w-full md:w-48 h-12 text-lg bg-primary hover:bg-primary/90 text-white shadow-neon-glow">Apply Now</Button>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1"><Bookmark size={18} className="mr-2" /> Save</Button>
              <Button variant="outline" size="icon"><Share2 size={18} /></Button>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Job Description */}
          <Card className="glass p-6 md:p-8 space-y-6">
            <section>
              <h2 className="text-xl font-heading font-bold text-text mb-4">About the Role</h2>
              <div className="space-y-4 text-text-secondary leading-relaxed">
                <p>We are looking for an experienced Senior Frontend Engineer to join our core product team. You will be responsible for building exceptional user experiences for our next-generation AI platform.</p>
                <p>The ideal candidate is deeply passionate about web performance, accessibility, and modern React patterns. You will work closely with design, product, and backend teams to deliver high-quality features.</p>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-heading font-bold text-text mb-4">Key Responsibilities</h2>
              <ul className="space-y-3 text-text-secondary">
                {[
                  'Architect and implement complex UI components using React and Tailwind CSS.',
                  'Collaborate with product managers and designers to iterate on features.',
                  'Optimize application for maximum speed and scalability.',
                  'Mentor junior developers and participate in code reviews.'
                ].map((item, i) => (
                  <li key={i} className="flex gap-3"><CheckCircle size={20} className="text-primary shrink-0" /> <span>{item}</span></li>
                ))}
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-heading font-bold text-text mb-4">Required Skills</h2>
              <div className="flex flex-wrap gap-2">
                {['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'GraphQL', 'Jest'].map(skill => (
                  <Badge key={skill} className="bg-primary/10 text-primary border-primary/30 px-3 py-1.5 text-sm">{skill}</Badge>
                ))}
              </div>
            </section>
          </Card>
        </div>

        <div className="space-y-6">
          {/* AI Match Card */}
          <Card className="glass p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
            <h3 className="text-lg font-heading font-bold text-text mb-4">AI Match Analysis</h3>
            <div className="flex items-center gap-4 mb-6">
              <div className="relative w-20 h-20 flex items-center justify-center rounded-full border-4 border-card-light border-t-accent">
                <span className="text-2xl font-bold font-heading text-text neon-text-accent">92%</span>
              </div>
              <div>
                <p className="font-semibold text-text">Excellent Match</p>
                <p className="text-sm text-text-secondary">Based on your profile and skills</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs mb-1"><span className="text-text-secondary">Skills Match</span><span className="text-text">95%</span></div>
                <div className="w-full bg-card-light rounded-full h-1.5"><div className="bg-success h-1.5 rounded-full" style={{width: '95%'}}></div></div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1"><span className="text-text-secondary">Experience Match</span><span className="text-text">88%</span></div>
                <div className="w-full bg-card-light rounded-full h-1.5"><div className="bg-accent h-1.5 rounded-full" style={{width: '88%'}}></div></div>
              </div>
            </div>
            <Button className="w-full mt-6 bg-card-light hover:bg-card-lighter text-text" asChild><Link to="/candidate/ai-tools">View Gap Analysis</Link></Button>
          </Card>

          {/* Company Info */}
          <Card className="glass p-6">
            <h3 className="text-lg font-heading font-bold text-text mb-4">About the Company</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-sm text-text-secondary">
                <Building size={18} className="text-text-muted" /> <span>Enterprise AI Solutions</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-text-secondary">
                <Users size={18} className="text-text-muted" /> <span>500-1000 Employees</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-text-secondary">
                <Globe size={18} className="text-text-muted" /> <a href="#" className="hover:text-primary transition-colors">cyberdyne.ai</a>
              </div>
              <p className="text-sm text-text-secondary mt-2">CyberDyne is a leading artificial intelligence company focused on building tools for the future of work.</p>
              <Button variant="link" className="text-primary p-0 h-auto">View Company Profile &rarr;</Button>
            </div>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}
