import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Hexagon, Menu, X } from 'lucide-react';
import { NAV_LINKS } from '@/utils/constants';
import { cn } from '@/utils/helpers';
import MobileNav from './MobileNav';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={cn(
          'fixed top-0 w-full z-50 transition-all duration-300',
          scrolled ? 'py-3 glass-strong border-b border-border' : 'py-5 bg-transparent'
        )}
      >
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 relative group z-50">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-card border border-primary/30 group-hover:border-primary/60 transition-colors">
            <Hexagon className="w-6 h-6 text-primary group-hover:text-accent transition-colors" /></div>
            <span className="font-heading font-bold text-xl tracking-wider text-text group-hover:neon-text transition-all">
              SpiderWeb<span className="text-primary">.AI</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            {NAV_LINKS?.map((link) => (
              <a
                key={link.name}
                href={link.path}
                className="text-sm font-medium text-text-secondary hover:text-text hover:neon-text transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <Link to="/login" className="text-sm font-medium text-text hover:text-primary transition-colors">
              Log in
            </Link>
            <Link
              to="/register"
              className="px-5 py-2.5 rounded-full bg-primary/10 border border-primary/50 text-primary font-medium hover:bg-primary hover:text-white transition-all neon-glow"
            >
              Get Started
            </Link>
          </div>

          <button
            className="md:hidden p-2 text-text hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </motion.nav>

      <MobileNav isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
    </>
  );
}
