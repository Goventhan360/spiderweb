import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, MapPin, DollarSign, Briefcase, Filter, X, Bookmark, Clock, CheckCircle } from 'lucide-react';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';
import EmptyState from '@/components/ui/EmptyState';
import { Link } from 'react-router';

export default function JobSearch() {
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const pageVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5, staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  // Demo jobs
  const jobs = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    title: ['Frontend Engineer', 'Full Stack Developer', 'React Native Developer', 'UI/UX Designer'][i % 4],
    company: ['CyberDyne', 'OmniCorp', 'Stark Industries', 'Wayne Enterprises'][i % 4],
    location: ['Remote', 'San Francisco, CA', 'New York, NY', 'Austin, TX'][i % 4],
    salary: '$120k - $150k',
    type: 'Full-time',
    mode: ['Remote', 'Hybrid', 'On-site'][i % 3],
    posted: '2 days ago',
    skills: ['React', 'TypeScript', 'Tailwind', 'Node.js'],
    match: 85 + i
  }));

  return (
    <motion.div variants={pageVariants} initial="hidden" animate="visible" className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Search Header */}
      <div className="mb-8 space-y-4">
        <h1 className="text-3xl font-heading font-bold text-text">Find Your Next Role</h1>
        <div className="flex gap-2 w-full max-w-4xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={20} />
            <Input className="w-full pl-10 h-12 bg-card border-border-light text-lg" placeholder="Search by job title, skill, or company..." />
          </div>
          <Button className="h-12 px-6 bg-primary hover:bg-primary/90 text-white shadow-neon-glow hidden md:flex">Search</Button>
          <Button variant="outline" className="h-12 md:hidden" onClick={() => setIsFilterOpen(!isFilterOpen)}>
            <Filter size={20} />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters Sidebar */}
        <motion.div 
          variants={itemVariants}
          className={`${isFilterOpen ? 'block' : 'hidden'} md:block w-full md:w-64 space-y-6 flex-shrink-0`}
        >
          <Card className="glass p-5 space-y-6">
            <div className="flex justify-between items-center md:hidden">
              <h3 className="font-heading font-bold">Filters</h3>
              <Button variant="ghost" size="sm" onClick={() => setIsFilterOpen(false)}><X size={16} /></Button>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-text border-b border-border-light pb-2">Job Type</h4>
              {['Full-time', 'Part-time', 'Contract', 'Freelance'].map(type => (
                <label key={type} className="flex items-center gap-2 text-sm text-text-secondary cursor-pointer hover:text-text">
                  <input type="checkbox" className="rounded border-border bg-card-light text-primary focus:ring-primary" />
                  {type}
                </label>
              ))}
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-text border-b border-border-light pb-2">Work Mode</h4>
              {['Remote', 'Hybrid', 'On-site'].map(mode => (
                <label key={mode} className="flex items-center gap-2 text-sm text-text-secondary cursor-pointer hover:text-text">
                  <input type="checkbox" className="rounded border-border bg-card-light text-primary focus:ring-primary" />
                  {mode}
                </label>
              ))}
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold text-text border-b border-border-light pb-2">Experience Level</h4>
              {['Entry Level', 'Mid Level', 'Senior Level', 'Lead / Manager'].map(level => (
                <label key={level} className="flex items-center gap-2 text-sm text-text-secondary cursor-pointer hover:text-text">
                  <input type="checkbox" className="rounded border-border bg-card-light text-primary focus:ring-primary" />
                  {level}
                </label>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Results */}
        <div className="flex-1 space-y-4">
          <div className="flex justify-between items-center mb-4">
            <p className="text-text-secondary"><span className="text-text font-bold">245</span> jobs found</p>
            <select className="bg-card border border-border-light rounded-md px-3 py-1.5 text-sm text-text focus:outline-none focus:border-primary">
              <option>Most Relevant</option>
              <option>Most Recent</option>
              <option>Highest Salary</option>
            </select>
          </div>

          <div className="space-y-4">
            {jobs.map((job) => (
              <motion.div key={job.id} variants={itemVariants}>
                <Card className="glass p-5 hover-card border-border-light hover:border-primary/50 transition-all group">
                  <div className="flex justify-between items-start">
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg bg-card-light flex items-center justify-center font-heading font-bold text-xl text-primary border border-border-light">
                        {job.company[0]}
                      </div>
                      <div>
                        <Link to={`/candidate/jobs/${job.id}`} className="text-lg font-heading font-semibold text-text group-hover:text-primary transition-colors">
                          {job.title}
                        </Link>
                        <p className="text-text-secondary text-sm mb-2">{job.company}</p>
                        
                        <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-text-secondary mb-3">
                          <span className="flex items-center gap-1"><MapPin size={14} /> {job.location} • {job.mode}</span>
                          <span className="flex items-center gap-1"><DollarSign size={14} /> {job.salary}</span>
                          <span className="flex items-center gap-1"><Briefcase size={14} /> {job.type}</span>
                          <span className="flex items-center gap-1"><Clock size={14} /> {job.posted}</span>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {job.skills.map(skill => (
                            <Badge key={skill} variant="outline" className="text-xs bg-card-light border-border-light">{skill}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-end gap-3">
                      <Button variant="ghost" size="icon" className="text-text-muted hover:text-primary rounded-full">
                        <Bookmark size={20} />
                      </Button>
                      <div className="flex flex-col items-center">
                        <div className="text-xs text-text-secondary mb-1">AI Match</div>
                        <div className="relative w-10 h-10 flex items-center justify-center rounded-full border-2 border-border-light border-t-accent text-xs font-bold text-accent">
                          {job.match}%
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-center pt-6">
            <Button variant="outline" className="px-8">Load More</Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
