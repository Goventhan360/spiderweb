import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Sparkles } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-32 relative overflow-hidden flex items-center justify-center">
      <div className="absolute inset-0 bg-gradient-mesh opacity-60"></div>
      
      {/* Glow Orbs */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-72 h-72 bg-primary/30 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-72 h-72 bg-accent/30 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="glass-strong border-primary/40 rounded-3xl p-12 md:p-20 max-w-4xl mx-auto shadow-[0_0_50px_rgba(124,58,237,0.2)]"
        >
          <div className="flex justify-center mb-6">
            <div className="p-3 bg-primary/20 rounded-full border border-primary/50 text-primary">
              <Sparkles className="w-8 h-8" />
            </div>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">Ready to Build Your Web?</h2>
          <p className="text-lg md:text-xl text-text-secondary mb-10 max-w-2xl mx-auto">
            Join thousands of professionals and top companies using SpiderWeb AI to redefine the future of talent networking.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              to="/register" 
              className="px-8 py-4 rounded-full bg-primary text-white font-bold text-lg hover:bg-primary/90 transition-all hover:scale-105 shadow-[0_0_20px_rgba(124,58,237,0.5)] w-full sm:w-auto text-center"
            >
              Get Started Free
            </Link>
            <Link 
              to="/contact" 
              className="px-8 py-4 rounded-full glass border-border hover:border-primary/50 text-text font-bold text-lg transition-all hover:bg-card-light w-full sm:w-auto text-center"
            >
              Contact Sales
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
