import { motion } from 'framer-motion';
import { Upload, Cpu, Target, Briefcase, GraduationCap, LineChart } from 'lucide-react';

const steps = [
  { icon: Upload, title: "Upload Profile", desc: "Share your resume and experience." },
  { icon: Cpu, title: "AI Analysis", desc: "Extract skills and parse semantics." },
  { icon: Target, title: "ATS Scoring", desc: "Evaluate match potential instantly." },
  { icon: Briefcase, title: "Job Matching", desc: "Find roles that fit perfectly." },
  { icon: LineChart, title: "Skill Gap", desc: "Identify areas for improvement." },
  { icon: GraduationCap, title: "Career Path", desc: "Get a custom learning roadmap." },
];

export default function AIShowcase() {
  return (
    <section id="ai-tools" className="py-24 bg-dark-light relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">AI-Powered Career Intelligence</h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">Watch how our neural network analyzes your profile to architect your ideal career trajectory.</p>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Connecting Line */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-border -translate-y-1/2">
            <motion.div 
              className="h-full bg-gradient-primary shadow-[0_0_10px_rgba(124,58,237,0.8)]"
              initial={{ width: "0%" }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              viewport={{ once: true }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 md:gap-0">
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.2 }}
                viewport={{ once: true }}
                className="relative flex flex-col items-center group cursor-pointer"
              >
                <div className="w-16 h-16 rounded-2xl glass border border-primary/30 flex items-center justify-center z-10 bg-dark mb-4 group-hover:scale-110 group-hover:border-primary group-hover:shadow-[0_0_20px_rgba(124,58,237,0.4)] transition-all">
                  <step.icon className="w-8 h-8 text-primary group-hover:text-accent transition-colors" />
                </div>
                <div className="text-center md:absolute md:top-20 md:w-32 bg-card/80 backdrop-blur-sm p-3 rounded-xl border border-border opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                  <h4 className="font-semibold text-sm text-text mb-1">{step.title}</h4>
                  <p className="text-xs text-text-muted">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
