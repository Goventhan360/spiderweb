import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { TESTIMONIALS } from '@/utils/constants';
import { getInitials } from '@/utils/helpers';

export default function TestimonialsSection() {
  return (
    <section className="py-24 bg-dark-light relative z-10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">What Our Network Says</h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">Success stories from candidates and companies who found their perfect match.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS?.map((testimonial, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.2 }}
              viewport={{ once: true }}
              className="glass p-8 rounded-2xl border border-border flex flex-col justify-between hover:border-primary/30 transition-all hover:-translate-y-1"
            >
              <div>
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-warning text-warning" />
                  ))}
                </div>
                <p className="text-text leading-relaxed italic mb-8">"{testimonial.text}"</p>
              </div>
              
              <div className="flex items-center gap-4 mt-auto">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50 text-primary font-bold">
                  {getInitials(testimonial.name)}
                </div>
                <div>
                  <h4 className="font-semibold text-text">{testimonial.name}</h4>
                  <p className="text-sm text-text-muted">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
