import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Target, Edit3, Compass, LayoutDashboard, MessageSquare, BookOpen, Sparkles, X, ChevronRight } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';

export default function AITools() {
  const [activeTool, setActiveTool] = useState(null);

  const pageVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5, staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const tools = [
    { id: 'resume', title: 'Resume Analyzer', desc: 'Get ATS score and analysis for your resume', icon: <FileText size={24} />, color: 'text-primary' },
    { id: 'match', title: 'AI Job Matching', desc: 'Find best-fit jobs based on your exact profile', icon: <Target size={24} />, color: 'text-accent' },
    { id: 'builder', title: 'Resume Builder', desc: 'AI-generated professional summary & bullets', icon: <Edit3 size={24} />, color: 'text-secondary' },
    { id: 'coach', title: 'Career Coach', desc: 'Personalized career advice & next steps', icon: <Compass size={24} />, color: 'text-success' },
    { id: 'gap', title: 'Skill Gap Analysis', desc: 'Compare your skills vs job requirements', icon: <LayoutDashboard size={24} />, color: 'text-warning' },
    { id: 'interview', title: 'Interview Prep', desc: 'AI-generated questions and mock interviews', icon: <MessageSquare size={24} />, color: 'text-primary' },
    { id: 'cover', title: 'Cover Letter Gen', desc: 'Generate tailored letters for specific jobs', icon: <FileText size={24} />, color: 'text-accent' },
    { id: 'learning', title: 'Learning Roadmap', desc: 'Structured learning path to reach your goals', icon: <BookOpen size={24} />, color: 'text-secondary' },
  ];

  return (
    <motion.div variants={pageVariants} initial="hidden" animate="visible" className="p-4 md:p-6 max-w-7xl mx-auto space-y-8 relative">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <h1 className="text-4xl font-heading font-bold text-text mb-4 inline-flex items-center justify-center gap-3">
          <Sparkles className="text-primary animate-pulse" size={32} /> AI Tools Hub
        </h1>
        <p className="text-text-secondary text-lg">Supercharge your job search with our suite of intelligent career tools designed to give you the competitive edge.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {tools.map((tool) => (
          <motion.div key={tool.id} variants={itemVariants}>
            <Card 
              className="glass p-6 hover-card cursor-pointer h-full flex flex-col items-start border-border-light hover:border-primary/50 group"
              onClick={() => setActiveTool(tool.id)}
            >
              <div className={`p-3 rounded-xl bg-card-light mb-4 border border-border-light group-hover:border-primary/30 transition-colors ${tool.color}`}>
                {tool.icon}
              </div>
              <h3 className="text-lg font-heading font-bold text-text mb-2">{tool.title}</h3>
              <p className="text-sm text-text-secondary mb-4 flex-grow">{tool.desc}</p>
              <Button variant="ghost" className="w-full justify-between px-0 text-text hover:text-primary mt-auto">
                Launch Tool <ChevronRight size={16} />
              </Button>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Tool Modal / Inline Section Overlay */}
      {activeTool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setActiveTool(null)}>
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-card border border-primary/30 shadow-[0_0_50px_rgba(124,58,237,0.15)] w-full max-w-4xl rounded-2xl overflow-hidden relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-border flex justify-between items-center bg-card-light">
              <h2 className="text-xl font-heading font-bold text-text flex items-center gap-2">
                <Sparkles className="text-primary" size={20} /> 
                {tools.find(t => t.id === activeTool)?.title}
              </h2>
              <button onClick={() => setActiveTool(null)} className="text-text-muted hover:text-white"><X size={24} /></button>
            </div>
            <div className="p-6 md:p-8 min-h-[400px] max-h-[70vh] overflow-y-auto">
              {/* Mock content based on active tool */}
              {activeTool === 'resume' && (
                <div className="space-y-6">
                  <p className="text-text-secondary">Paste your resume content here for instant AI analysis.</p>
                  <textarea className="w-full h-48 bg-dark p-4 rounded-lg border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none text-text-secondary font-mono text-sm" placeholder="Paste resume text..."></textarea>
                  <Button className="w-full bg-primary text-white shadow-neon-glow h-12">Analyze Resume</Button>
                </div>
              )}
              {activeTool !== 'resume' && (
                <div className="flex flex-col items-center justify-center h-64 text-center">
                  <div className="w-16 h-16 rounded-full border-2 border-primary border-t-transparent animate-spin mb-4"></div>
                  <h3 className="text-lg font-heading font-bold text-text mb-2">Initializing AI Engine...</h3>
                  <p className="text-text-secondary">Loading {tools.find(t => t.id === activeTool)?.title} workspace.</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}
