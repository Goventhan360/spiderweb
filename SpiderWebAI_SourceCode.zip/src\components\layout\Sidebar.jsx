import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import * as Icons from 'lucide-react';
import { cn } from '@/utils/helpers';
import { useAuth } from '@/contexts/AuthContext';

export default function Sidebar({ role, navItems, isOpen, setIsOpen }) {
  const location = useLocation();
  const { user, profile, signOut } = useAuth();

  const renderIcon = (iconName) => {
    const IconComponent = Icons[iconName] || Icons.Circle;
    return <IconComponent className="w-5 h-5" />;
  };

  const sidebarContent = (
    <div className="flex flex-col h-full glass border-r border-border w-64">
      <div className="p-6 flex items-center gap-3">
        <Icons.Hexagon className="w-8 h-8 text-primary" />
        <span className="font-heading font-bold text-lg tracking-wide neon-text">SpiderWeb.AI</span>
      </div>

      <div className="flex-1 overflow-y-auto py-4 custom-scrollbar">
        <nav className="space-y-1 px-3">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
            return (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  'flex items-center gap-3 px-3 py-3 rounded-lg transition-all',
                  isActive 
                    ? 'bg-primary/10 text-primary border-l-4 border-primary neon-glow' 
                    : 'text-text-secondary hover:bg-card-light hover:text-text'
                )}
              >
                {renderIcon(item.icon)}
                <span className="font-medium text-sm">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50 text-primary font-bold">
            {profile?.full_name?.charAt(0) || user?.email?.charAt(0) || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-text truncate">{profile?.full_name || 'User'}</p>
            <p className="text-xs text-text-muted truncate capitalize">{role}</p>
          </div>
        </div>
        <button 
          onClick={() => signOut()}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-danger/10 text-danger hover:bg-danger/20 transition-colors text-sm font-medium"
        >
          <Icons.LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:block h-full z-20 shrink-0">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="absolute inset-0 bg-dark/80 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
            className="relative z-10 w-64 h-full"
          >
            <button 
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 text-text-secondary hover:text-text"
            >
              <Icons.X className="w-6 h-6" />
            </button>
            {sidebarContent}
          </motion.div>
        </div>
      )}
    </>
  );
}
