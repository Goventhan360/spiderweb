import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Book, Briefcase, Code, Award, FileText, Upload, Save, CheckCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/Tabs';
import Input from '@/components/ui/Input';
import ProgressBar from '@/components/ui/ProgressBar';
import Skeleton from '@/components/ui/Skeleton';

export default function Profile() {
  const { profile, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('personal');

  const pageVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  if (loading) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  return (
    <motion.div variants={pageVariants} initial="hidden" animate="visible" className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row gap-6 items-start">
        <div className="w-full md:w-1/3 space-y-6">
          <Card className="glass p-6 flex flex-col items-center text-center">
            <div className="relative group">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-card-light relative bg-card-lighter flex items-center justify-center">
                {profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User size={48} className="text-text-secondary" />
                )}
                <div className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center cursor-pointer transition-all">
                  <Upload className="text-white" />
                </div>
              </div>
            </div>
            <h2 className="mt-4 text-xl font-heading font-bold text-text">{profile?.full_name || 'Your Name'}</h2>
            <p className="text-text-secondary text-sm mb-4">Frontend Developer</p>
            <div className="w-full">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-text-secondary">Profile Completion</span>
                <span className="text-primary font-bold">85%</span>
              </div>
              <ProgressBar value={85} className="h-2" />
            </div>
          </Card>

          <Card className="glass p-4">
            <TabsList className="flex-col bg-transparent h-auto space-y-2" value={activeTab} onValueChange={setActiveTab}>
              <TabsTrigger value="personal" className="w-full justify-start p-3 data-[state=active]:bg-primary/20 data-[state=active]:text-primary border border-transparent data-[state=active]:border-primary/50"><User size={18} className="mr-2"/> Personal Info</TabsTrigger>
              <TabsTrigger value="education" className="w-full justify-start p-3"><Book size={18} className="mr-2"/> Education</TabsTrigger>
              <TabsTrigger value="experience" className="w-full justify-start p-3"><Briefcase size={18} className="mr-2"/> Experience</TabsTrigger>
              <TabsTrigger value="projects" className="w-full justify-start p-3"><Code size={18} className="mr-2"/> Projects</TabsTrigger>
              <TabsTrigger value="skills" className="w-full justify-start p-3"><Award size={18} className="mr-2"/> Skills</TabsTrigger>
              <TabsTrigger value="resume" className="w-full justify-start p-3"><FileText size={18} className="mr-2"/> Resume</TabsTrigger>
            </TabsList>
          </Card>
        </div>

        <div className="w-full md:w-2/3">
          <Tabs value={activeTab} className="w-full">
            <TabsContent value="personal" className="mt-0">
              <Card className="glass p-6">
                <h3 className="text-xl font-heading font-bold text-text mb-6">Personal Information</h3>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">Full Name</label>
                      <Input defaultValue={profile?.full_name} placeholder="John Doe" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">Headline</label>
                      <Input placeholder="Senior React Developer" />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm text-text-secondary">Bio</label>
                      <textarea className="w-full bg-card-light border border-border rounded-md p-3 text-text focus:border-primary focus:ring-1 focus:ring-primary outline-none min-h-[100px]" placeholder="Tell us about yourself..." />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">Location</label>
                      <Input placeholder="San Francisco, CA" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">Phone</label>
                      <Input placeholder="+1 (555) 000-0000" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">LinkedIn</label>
                      <Input placeholder="https://linkedin.com/in/username" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-text-secondary">GitHub</label>
                      <Input placeholder="https://github.com/username" />
                    </div>
                  </div>
                  <div className="pt-4 flex justify-end">
                    <Button type="button" className="bg-primary hover:bg-primary/90 text-white shadow-neon-glow"><Save size={18} className="mr-2"/> Save Changes</Button>
                  </div>
                </form>
              </Card>
            </TabsContent>
            
            <TabsContent value="resume" className="mt-0">
              <Card className="glass p-6">
                <h3 className="text-xl font-heading font-bold text-text mb-6">Resume Management</h3>
                <div className="border-2 border-dashed border-border-light rounded-lg p-10 flex flex-col items-center justify-center text-center bg-card-light/50 hover:bg-card-light transition-colors cursor-pointer">
                  <Upload size={40} className="text-primary mb-4" />
                  <p className="text-text font-medium mb-1">Click to upload or drag and drop</p>
                  <p className="text-sm text-text-secondary">PDF, DOCX up to 5MB</p>
                </div>
                
                <div className="mt-8 space-y-4">
                  <h4 className="font-heading font-semibold text-text">Current Resume</h4>
                  <div className="flex items-center justify-between p-4 bg-card-light rounded-lg border border-border">
                    <div className="flex items-center gap-3">
                      <FileText className="text-secondary" size={24} />
                      <div>
                        <p className="text-text font-medium">John_Doe_Resume_2026.pdf</p>
                        <p className="text-xs text-text-secondary">Uploaded 2 days ago • 1.2 MB</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xs text-text-secondary">AI Score</p>
                        <p className="text-accent font-bold">78/100</p>
                      </div>
                      <Button variant="outline" size="sm">Replace</Button>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>
            {/* Additional tabs would be implemented similarly */}
            <TabsContent value="education" className="mt-0"><Card className="glass p-6"><h3 className="text-xl font-heading font-bold text-text mb-6">Education</h3><Button variant="outline">+ Add Education</Button></Card></TabsContent>
            <TabsContent value="experience" className="mt-0"><Card className="glass p-6"><h3 className="text-xl font-heading font-bold text-text mb-6">Experience</h3><Button variant="outline">+ Add Experience</Button></Card></TabsContent>
            <TabsContent value="projects" className="mt-0"><Card className="glass p-6"><h3 className="text-xl font-heading font-bold text-text mb-6">Projects</h3><Button variant="outline">+ Add Project</Button></Card></TabsContent>
            <TabsContent value="skills" className="mt-0"><Card className="glass p-6"><h3 className="text-xl font-heading font-bold text-text mb-6">Skills</h3><Button variant="outline">+ Add Skill</Button></Card></TabsContent>
          </Tabs>
        </div>
      </div>
    </motion.div>
  );
}
