import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { PRICING_PLANS } from '@/utils/constants';
import { cn } from '@/utils/helpers';

export default function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="py-24 relative z-10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">Simple, Transparent Pricing</h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto mb-8">Invest in your career or hiring pipeline with plans designed to scale.</p>
          
          <div className="inline-flex items-center p-1 bg-card rounded-full border border-border">
            <button 
              onClick={() => setIsAnnual(false)}
              className={cn("px-6 py-2 rounded-full text-sm font-medium transition-all", !isAnnual ? "bg-primary text-white shadow-lg" : "text-text-secondary hover:text-text")}
            >
              Monthly
            </button>
            <button 
              onClick={() => setIsAnnual(true)}
              className={cn("px-6 py-2 rounded-full text-sm font-medium transition-all", isAnnual ? "bg-primary text-white shadow-lg" : "text-text-secondary hover:text-text")}
            >
              Annually <span className="text-xs text-accent ml-1">Save 20%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PRICING_PLANS?.map((plan, idx) => {
            const isPopular = plan.name === 'Pro';
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className={cn(
                  "relative p-8 rounded-3xl flex flex-col",
                  isPopular 
                    ? "glass-strong border-primary/50 transform md:-translate-y-4 shadow-[0_0_30px_rgba(124,58,237,0.2)]" 
                    : "glass border-border mt-4"
                )}
              >
                {isPopular && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1 bg-primary text-white text-xs font-bold rounded-full uppercase tracking-wider">
                    Most Popular
                  </div>
                )}
                
                <h3 className="text-2xl font-semibold mb-2">{plan.name}</h3>
                <p className="text-text-muted text-sm mb-6 h-10">{plan.description}</p>
                
                <div className="mb-8">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-text-muted">/mo</span>
                </div>
                
                <ul className="space-y-4 mb-8 flex-1">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="mt-1 bg-primary/20 p-1 rounded-full text-primary">
                        <Check className="w-3 h-3" />
                      </div>
                      <span className="text-sm text-text-secondary">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button className={cn(
                  "w-full py-3 rounded-xl font-semibold transition-all",
                  isPopular 
                    ? "bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/30" 
                    : "bg-card-light hover:bg-card border border-border text-text"
                )}>
                  {plan.cta}
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
