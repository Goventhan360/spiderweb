import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useNavigate } from 'react-router';
import { Mail, Lock, LogIn } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { pageVariants } from '@/hooks/useAnimations';
import toast from 'react-hot-toast';
import { cn } from '@/utils/helpers';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export default function Login() {
  const { signIn, signInWithGoogle, isDemo } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: isDemo ? 'demo@spiderweb.ai' : '',
      password: isDemo ? 'password123' : '',
    }
  });

  const onSubmit = async (data) => {
    setIsLoading(true);
    const { error } = await signIn(data.email, data.password);
    setIsLoading(false);
    
    if (error) {
      toast.error(error.message || 'Failed to login');
    } else {
      toast.success('Logged in successfully');
      navigate('/dashboard');
    }
  };

  return (
    <motion.div 
      className="min-h-screen flex items-center justify-center p-4 bg-dark relative overflow-hidden"
      variants={pageVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-dark to-dark pointer-events-none" />
      
      <div className="w-full max-w-md glass p-8 rounded-2xl relative z-10 neon-glow">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-heading text-text neon-text mb-2">SpiderWeb AI</h1>
          <p className="text-text-secondary">Login to your account</p>
        </div>

        {isDemo && (
          <div className="mb-6 p-3 bg-primary/20 border border-primary/50 rounded-lg text-sm text-text-secondary">
            Demo mode active. Use the pre-filled credentials to login.
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-5 h-5 text-text-muted" />
              <input 
                {...register('email')}
                type="email"
                placeholder="Email Address"
                className={cn(
                  "w-full bg-dark-light border rounded-lg py-2.5 pl-10 pr-4 text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors",
                  errors.email ? "border-danger" : "border-border"
                )}
              />
            </div>
            {errors.email && <p className="text-danger text-sm mt-1">{errors.email.message}</p>}
          </div>

          <div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-5 h-5 text-text-muted" />
              <input 
                {...register('password')}
                type="password"
                placeholder="Password"
                className={cn(
                  "w-full bg-dark-light border rounded-lg py-2.5 pl-10 pr-4 text-text focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors",
                  errors.password ? "border-danger" : "border-border"
                )}
              />
            </div>
            {errors.password && <p className="text-danger text-sm mt-1">{errors.password.message}</p>}
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input type="checkbox" className="rounded border-border bg-dark-light text-primary focus:ring-primary" />
              <span className="text-text-secondary">Remember me</span>
            </label>
            <Link to="/forgot-password" className="text-primary hover:text-primary/80 transition-colors">
              Forgot Password?
            </Link>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? <span className="animate-spin w-5 h-5 border-2 border-white/30 border-t-white rounded-full" /> : <><LogIn className="w-5 h-5" /> Login</>}
          </button>
        </form>

        <div className="mt-6 flex items-center gap-4">
          <div className="flex-1 h-px bg-border" />
          <span className="text-text-muted text-sm">OR</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        <button 
          onClick={() => signInWithGoogle()}
          className="w-full mt-6 bg-dark-light hover:bg-card border border-border text-text font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
            <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
          Continue with Google
        </button>

        <p className="text-center mt-6 text-text-secondary text-sm">
          Don't have an account? <Link to="/register" className="text-primary hover:text-primary/80 transition-colors">Register</Link>
        </p>
      </div>
    </motion.div>
  );
}
