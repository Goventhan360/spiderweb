import { motion } from 'framer-motion';
import { DEMO_COMPANIES } from '@/utils/constants';

export default function CompaniesSection() {
  // Double the array for seamless infinite scroll
  const companies = [...(DEMO_COMPANIES || []), ...(DEMO_COMPANIES || [])];

  return (
    <section className="py-20 border-y border-border overflow-hidden bg-dark">
      <div className="container mx-auto px-4 text-center mb-10">
        <p className="text-sm font-semibold tracking-widest text-text-muted uppercase">Trusted by Leading Innovative Companies</p>
      </div>

      <div className="relative w-full flex overflow-hidden">
        {/* Gradient Fades */}
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-dark to-transparent z-10 pointer-events-none"></div>
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-dark to-transparent z-10 pointer-events-none"></div>

        <motion.div 
          className="flex whitespace-nowrap items-center gap-8 py-4"
          animate={{ x: ["0%", "-50%"] }}
          transition={{ ease: "linear", duration: 25, repeat: Infinity }}
        >
          {companies.map((company, idx) => (
            <div 
              key={idx} 
              className="glass px-6 py-3 rounded-full flex items-center gap-3 border border-border/50 shrink-0 hover:border-primary/50 transition-colors cursor-default"
            >
              <div className="w-8 h-8 rounded-full bg-card flex items-center justify-center text-primary font-bold border border-primary/20">
                {company.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-bold text-text">{company.name}</p>
                <p className="text-xs text-text-muted">{company.industry}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
