import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Search, Building2 } from 'lucide-react';
import { APP_TAGLINE } from '@/utils/constants';

export default function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[128px] animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[128px] animate-pulse-glow" style={{ animationDelay: '2s' }} />

      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border-primary/30 text-sm font-medium text-primary mb-4 animate-fade-in">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            SpiderWeb AI 2.0 is Live
          </div>

          <h1 className="text-5xl md:text-7xl font-heading font-black tracking-tight leading-tight">
            Connect Talent Through <br className="hidden md:block" />
            <span className="gradient-text-animated">Intelligent Web Networks</span>
          </h1>

          <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto font-light">
            Find your dream job with AI-powered matching, career coaching, and intelligent networking. Built for the future of work.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <Link to="/register" className="w-full sm:w-auto px-8 py-4 rounded-full bg-primary hover:bg-primary/90 text-white font-semibold flex items-center justify-center gap-2 transition-all hover:scale-105 shadow-[0_0_20px_rgba(124,58,237,0.4)] hover:shadow-[0_0_30px_rgba(124,58,237,0.6)]">
              Get Started <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/jobs" className="w-full sm:w-auto px-8 py-4 rounded-full glass border-border hover:border-primary/50 text-text font-medium flex items-center justify-center gap-2 transition-all hover:bg-card-light">
              <Search className="w-5 h-5" /> Find Jobs
            </Link>
            <Link to="/hire" className="w-full sm:w-auto px-8 py-4 rounded-full bg-transparent border border-accent/30 text-accent font-medium flex items-center justify-center gap-2 transition-all hover:bg-accent/10">
              <Building2 className="w-5 h-5" /> Hire Talent
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
