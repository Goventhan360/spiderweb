import { motion } from 'framer-motion';
import { STATS } from '@/utils/constants';

export default function StatsSection() {
  return (
    <section className="py-24 relative z-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS?.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1, duration: 0.4 }}
              viewport={{ once: true }}
              className="glass p-6 rounded-2xl border border-border text-center group hover:border-primary/50 hover:shadow-[0_0_20px_rgba(124,58,237,0.15)] transition-all"
            >
              <div className="text-4xl md:text-5xl font-heading font-black text-transparent bg-clip-text gradient-primary mb-2 group-hover:scale-110 transition-transform">
                {stat.value}
              </div>
              <div className="text-sm md:text-base font-medium text-text-secondary">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
