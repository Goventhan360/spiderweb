import { useLocation } from 'react-router-dom';
import { Menu, Bell, Search, Settings, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export default function TopBar({ onMenuClick }) {
  const location = useLocation();
  const { profile } = useAuth();
  
  const getPageTitle = () => {
    const path = location.pathname.split('/').filter(Boolean).pop();
    if (!path) return 'Dashboard';
    return path.charAt(0).toUpperCase() + path.slice(1).replace('-', ' ');
  };

  return (
    <header className="h-16 glass border-b border-border flex items-center justify-between px-4 md:px-6 z-10 shrink-0">
      <div className="flex items-center gap-4">
        <button 
          onClick={onMenuClick}
          className="md:hidden p-2 -ml-2 text-text-secondary hover:text-text transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-heading font-semibold text-text">{getPageTitle()}</h1>
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden md:flex relative group">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-text-muted group-focus-within:text-primary transition-colors" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="bg-card-light border border-border rounded-full pl-9 pr-4 py-1.5 text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 w-64 transition-all"
          />
        </div>

        <button className="relative p-2 text-text-secondary hover:text-primary transition-colors rounded-full hover:bg-primary/10">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-danger rounded-full border-2 border-dark"></span>
        </button>

        <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-white font-medium text-sm cursor-pointer shadow-lg shadow-primary/20">
          {profile?.full_name?.charAt(0) || 'U'}
        </div>
      </div>
    </header>
  );
}
