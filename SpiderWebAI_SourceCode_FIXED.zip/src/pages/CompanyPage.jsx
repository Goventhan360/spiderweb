import { motion } from 'framer-motion';
import { MapPin, Globe, Users, Briefcase } from 'lucide-react';
import { DEMO_COMPANIES } from '@/utils/constants';
import { useParams } from 'react-router-dom';

export default function CompanyPage() {
  const { id } = useParams();
  const company = DEMO_COMPANIES[0]; // fallback demo data
  
  if (!company) return <div className="p-10 text-center text-text">Company not found</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      {/* Header Profile */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl overflow-hidden border border-border"
      >
        <div className="h-48 gradient-primary relative"></div>
        <div className="px-8 pb-8 relative">
          <div className="w-24 h-24 bg-card rounded-xl border-4 border-dark flex items-center justify-center -mt-12 mb-4 text-3xl font-bold text-primary shadow-lg">
            {company.name.charAt(0)}
          </div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-text mb-2">{company.name}</h1>
              <div className="flex flex-wrap items-center gap-4 text-text-secondary text-sm">
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> San Francisco, CA</span>
                <span className="flex items-center gap-1"><Users className="w-4 h-4" /> 500-1000 Employees</span>
                <span className="flex items-center gap-1"><Globe className="w-4 h-4" /> {company.industry}</span>
              </div>
            </div>
            <button className="px-6 py-2 rounded-lg bg-primary text-white font-medium hover:bg-primary/90 transition-colors">
              Follow Company
            </button>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} className="glass p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-semibold mb-4 text-text">About Us</h2>
            <p className="text-text-secondary leading-relaxed">
              We are a leading innovative company revolutionizing the {company.industry} space using cutting-edge technology and AI. 
              Our mission is to build tools that empower developers and creators globally.
            </p>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="glass p-6 rounded-2xl border border-border">
            <h2 className="text-xl font-semibold mb-4 text-text">Open Positions</h2>
            <div className="space-y-4">
              {[1, 2, 3].map((job) => (
                <div key={job} className="p-4 rounded-xl border border-border/50 hover:border-primary/30 bg-card-light transition-all flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <h3 className="font-medium text-text mb-1">Senior AI Engineer</h3>
                    <div className="flex items-center gap-3 text-xs text-text-muted">
                      <span>Full-time</span> • <span>Remote</span> • <span>$150k - $200k</span>
                    </div>
                  </div>
                  <button className="px-4 py-1.5 rounded-lg border border-primary text-primary text-sm hover:bg-primary/10 transition-colors self-start md:self-center">
                    Apply Now
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="glass p-6 rounded-2xl border border-border">
            <h2 className="text-lg font-semibold mb-4 text-text">Tech Stack</h2>
            <div className="flex flex-wrap gap-2">
              {['React', 'Node.js', 'Python', 'TensorFlow', 'PostgreSQL', 'AWS'].map(tech => (
                <span key={tech} className="px-3 py-1 rounded-md bg-card-light text-xs font-medium text-text-secondary border border-border">
                  {tech}
                </span>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="glass p-6 rounded-2xl border border-border">
            <h2 className="text-lg font-semibold mb-4 text-text">Benefits</h2>
            <ul className="space-y-3 text-sm text-text-secondary">
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> Fully Remote Work</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> Health, Dental, Vision</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> Unlimited PTO</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> 401(k) Matching</li>
            </ul>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
